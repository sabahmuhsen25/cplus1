#include <vector>
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>


using namespace std;


void heapify(vector<double>& arr, int n, int i)
{
    int largest = i;    // Vi gissar att toppen är störst
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < n && arr[left] > arr[largest])
    {
        largest = left;
    }
    if (right < n && arr[right] > arr[largest])
    {
        largest = right; 
    }
    // Sätt största talet på toppen
    if (largest != i)
    {
        swap(arr[i], arr[largest]);
        heapify(arr, n, largest);
    }
}

void heapSort(vector<double>& arr)
{
    int n = arr.size();

    // Bygg Max-heap
    for (int i = n/2 -1; i >= 0; i--)
    {
        heapify(arr, n, i);
    }

    // Extrahera elementen från toppen (största talet -> slutet på arrayen)
    for (int i = n - 1; i >= 0; i--)
    {
        swap(arr[0], arr[i]);
        heapify(arr, i, 0);
    }
}

void printVector(const vector<double>& arr)
{
    for (int i=0; i<arr.size(); ++i)
    {
        cout << arr[i] << " ";
    }
    cout << "\n";
}

int main(int argc, char* argv[])
{
    ifstream my_input_file("sortering.csv");
    //ifstream my_input_file("data1.csv");
    vector<double>array; // at save data as double
    string Line, string_temp;
    while (getline(my_input_file, Line))
    {
        istringstream iss(Line);
        while (getline(iss, string_temp, ','))
        {
            // convert and add to vect directlly
            array.push_back(atof(string_temp.c_str()));
            
        }
    }
    // display converted value
    for (auto value: array)
    {
        cout << value << "\n";
       
    }
   
    
   
   vector<double>heapSortVector(array);
    heapSort(heapSortVector);
    printVector(heapSortVector);

    return 0;
}







